#!/bin/bash

while true
do
./wildrig-multi --algo lyra2vc0ban --url stratum+tcp://eu.gos.cx:4650 --user 8J1i7WJYiTbb92AcRjzfX1Pob6jiN1kJEG --pass c=RYO
sleep 5
done
